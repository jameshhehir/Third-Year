/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src;

import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author JimmyHehir
 */
public class CustomerDAO {
    
    private static final String DATABASE_URL = "jdbc:mysql://mysql1.it.nuigalway.ie:3306/mydb3525";
    private static final String USERNAME = "mydb3525hj";
    private static final String PASSWORD = "lu4wyn";
    
    public ArrayList<Customer> getCustomers() {
        ArrayList<Customer> cs = new ArrayList<Customer>();
        Connection con = null;
        Statement stmt = null;
        
        try {
            con = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM customers");
            
            while(rs.next()) {
                Customer c = new Customer();
                c.setCustomerNumber(rs.getInt(1));
                c.setCustomerName(rs.getString(2));
                c.setContactLastName(rs.getString(3));
                c.setContactFirstName(rs.getString(4));
                c.setPhone(rs.getString(5));
                c.setAddressLine1(rs.getString(6));
                c.setAddressLine2(rs.getString(7));
                c.setCity(rs.getString(8));
                c.setState(rs.getString(9));
                c.setPostalCode(rs.getString(10));
                c.setCountry(rs.getString(11));
                c.setSalesRepEmployeeNumber(rs.getInt(12));
                c.setCreditLimit(rs.getDouble(13));
                cs.add(c);
            }
            
        } catch (SQLException e) {e.printStackTrace();} 
        finally {
            try {
                if(stmt != null) stmt.close();
                if(con != null) con.close();
            } catch (SQLException e) {}
        }
        
        return cs;
    }
    
}
